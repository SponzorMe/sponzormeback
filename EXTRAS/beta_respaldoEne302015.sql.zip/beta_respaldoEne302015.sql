-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 28-01-2015 a las 12:58:34
-- Versión del servidor: 5.5.40-0ubuntu0.14.04.1
-- Versión de PHP: 5.5.9-1ubuntu4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `ebdb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_categories`
--

CREATE TABLE IF NOT EXISTS `web_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lang` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Volcado de datos para la tabla `web_categories`
--

INSERT INTO `web_categories` (`id`, `title`, `body`, `created_at`, `updated_at`, `lang`) VALUES
(1, 'Outdoor', 'All About the Bussines!', '2014-08-20 10:11:45', '2014-08-20 10:11:45', 'en'),
(2, 'Art & Culture', 'All About the Bussines!', '2014-08-20 10:11:45', '2014-08-20 10:11:45', 'en'),
(3, 'Dancing', 'All About the Bussines!', '2014-08-20 10:11:45', '2014-08-20 10:11:45', 'en'),
(4, 'Wellness', 'All About the Bussines!', '2014-08-20 10:11:45', '2014-08-20 10:11:45', 'en'),
(5, 'Career & Business', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(6, 'Eat & Foods', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(7, 'Belief', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(8, 'Sports & Fitness', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(9, 'Education', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(10, 'Photography', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(11, 'Languages', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(12, 'Books', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(13, 'Music', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(14, 'Technology', 'All About the Bussines!', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(15, 'Televisión', 'Televisión', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'es');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_events`
--

CREATE TABLE IF NOT EXISTS `web_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ends` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `organizer` int(10) NOT NULL,
  `logo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` int(10) NOT NULL,
  `topic` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `privacy` int(1) NOT NULL,
  `starts` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `location_reference` text NOT NULL,
  `state` int(2) NOT NULL,
  `image` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Volcado de datos para la tabla `web_events`
--

INSERT INTO `web_events` (`id`, `title`, `location`, `ends`, `organizer`, `logo`, `description`, `type`, `topic`, `created_at`, `updated_at`, `privacy`, `starts`, `location_reference`, `state`, `image`) VALUES
(1, 'Test de Sebas', 'La casa de sebas', '2014-09-13 03:00:00', 39, 'sebas.png', 'Correr por la casa', 1, 1, '2014-09-09 18:32:06', '2014-09-09 18:32:06', 1, '2014-09-10 03:00:00', '', 0, ''),
(2, 'Dormir', 'Dormir por la casa', '0000-00-00 00:00:00', 1, '', 'Test', 2, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '0000-00-00 00:00:00', '', 0, ''),
(29, 'Test de Carlos', 'Choco', '2014-09-17 03:00:00', 39, '', 'Nose', 4, 0, '2014-09-23 02:59:36', '2014-09-23 02:59:36', 0, '2014-09-04 03:00:00', '', 0, ''),
(30, 'Caminar por la casa', 'Arizona', '2014-10-30 04:00:00', 46, '', 'Nose', 5, 0, '2014-10-02 01:58:50', '2014-10-02 01:58:50', 0, '2014-10-22 03:00:00', '', 0, ''),
(31, 'Correr por la casa', 'Houston', '2014-12-31 03:00:00', 46, '', 'Nose', 12, 0, '2014-10-02 01:59:51', '2014-10-02 01:59:51', 0, '2014-12-31 03:00:00', '', 0, ''),
(32, 'Test', 'test', '2010-10-10 03:00:00', 9, '', 'test', 10, 0, '2014-10-14 23:19:18', '2014-10-14 23:19:18', 0, '2014-10-10 03:00:00', '', 0, ''),
(33, 'Test2', 'test2', '2014-12-10 03:00:00', 9, '', 'Test2', 1, 0, '2014-10-14 23:21:03', '2014-10-14 23:21:03', 1, '2010-10-10 03:00:00', '', 0, ''),
(34, 'a', 'a', '2014-10-14 05:00:00', 16, '', 'a', 5, 0, '2014-10-26 07:19:22', '2014-10-26 07:19:22', 0, '2014-10-09 05:00:00', '', 0, ''),
(35, 'Conozcamonos....', 'Berkerley, CA', '2014-10-25 05:00:00', 12, '', 'Ola ke ase', 8, 0, '2014-10-26 07:29:53', '2014-10-26 07:29:53', 0, '2014-10-25 05:00:00', '', 0, ''),
(36, 'Conozcamonos otra vez...', 'Berkerley, CA', '2014-11-05 06:00:00', 12, '', 'Tell me.\nConozcamonos otra vez...', 9, 0, '2014-10-31 10:07:20', '2014-10-31 10:07:20', 0, '2014-10-31 06:00:00', '', 0, ''),
(38, 'Conozcamonos otra vez...', 'Berkerley, CA', '2014-11-05 06:00:00', 12, '', 'Tell me.\nConozcamonos otra vez...', 9, 0, '2014-10-31 10:07:35', '2014-10-31 10:07:35', 0, '2014-10-31 06:00:00', '', 0, ''),
(40, 'Bootcamp PHP', 'Cra 67 # 167 - 61, Bogotá, Cundinamarca', '2013-06-08 05:00:00', 12, '', 'Requerimientos. \n  \nSi quieres sobrevivir a este Bootcamp deberas \nestar en forma!!! \nSaber sobre ciclos, funciones !!! \nSaber usar Google para buscar referencias !!!! \nSaber usar un editor de Texto, FTP y Configurar una base de datos !!!! \nMás info Aqui \n  \nPagos en efectivo. \n  \n Cuentas de Ahorros \n10172601311 \nCONVERGED SOLUTIONS \nBANCOLOMBIA \nMás info Aqui', 2, 0, '2014-11-15 13:23:29', '2014-11-15 13:23:29', 0, '2013-06-08 05:00:00', '', 0, ''),
(41, 'Bootcamp PHP', 'Cra 67 # 167 - 61, Bogotá, Cundinamarca', '2013-06-08 05:00:00', 12, '', 'Requerimientos. \n  \nSi quieres sobrevivir a este Bootcamp deberas \nestar en forma!!! \nSaber sobre ciclos, funciones !!! \nSaber usar Google para buscar referencias !!!! \nSaber usar un editor de Texto, FTP y Configurar una base de datos !!!! \nMás info Aqui \n  \nPagos en efectivo. \n  \n Cuentas de Ahorros \n10172601311 \nCONVERGED SOLUTIONS \nBANCOLOMBIA \nMás info Aqui', 2, 0, '2014-11-15 13:23:56', '2014-11-15 13:23:56', 0, '2013-06-08 05:00:00', '', 0, ''),
(42, 'Crash the DevFest in Mountain View', '1200 Crittenden Lane, Google Campus - Building CL2, Mountain View', '2014-11-16 06:00:00', 12, '', '<p>The DevFest is a full day event in Google Mountain View with workshops and talks by Google developers that will introduce us to new technologies and ideas.</p> <p>Come join us and enjoy a day of swag, learning and treats by Google. There''s more information here:<br/><a href="http://devfest2014.gdgsv.com/" class="linkified">http://devfest2014.gdgsv.com/</a></p> <p>Please register here too:<br/><a href="https://www.eventbrite.com/e/gdg-silicon-valley-devfest-2014-tickets-13571156695" class="lin', 14, 0, '2014-11-15 13:31:20', '2014-11-15 13:31:20', 0, '2014-11-16 06:00:00', '', 0, ''),
(43, 'Polymer Polytechnic Bogotá', 'Carrera 7 # 69-17, Atom House, Bogotá', '2014-11-29 06:00:00', 19, '', '<p><img src="http://photos2.meetupstatic.com/photos/event/d/6/4/4/600_418554852.jpeg" /></p> <p>Los Web Components son un nuevo conjunto de estándares emergentes que le permiten a los desarrolladores extender la plataforma Web creando sus propios elementos HTML. Imagina si la Web tuviera su propio SDK móvil y construir una aplicación Web fuera como juntar componentes bien encapsulados aplicando "scoped" CSS. </p> <p>Ese es el futuro que Web Components traerá. Y usando una librería como Polymer p', 14, 0, '2014-11-17 03:11:46', '2014-11-17 03:11:46', 0, '2014-11-29 06:00:00', '', 0, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_event_type`
--

CREATE TABLE IF NOT EXISTS `web_event_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lang` varchar(4) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `web_event_type`
--

INSERT INTO `web_event_type` (`id`, `name`, `description`, `updated_at`, `created_at`, `lang`) VALUES
(1, 'Charity', 'Give us your money', '2014-09-18 19:00:00', '0000-00-00 00:00:00', 'en'),
(2, 'recruitment', 'recruitment', '2014-09-18 19:00:17', '0000-00-00 00:00:00', 'en');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_groups`
--

CREATE TABLE IF NOT EXISTS `web_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `web_groups`
--

INSERT INTO `web_groups` (`id`, `name`, `permissions`, `created_at`, `updated_at`) VALUES
(4, 'Admins', '{"admin":1,"users":1,"sponsors":1}', '2014-10-08 07:17:33', '2014-10-08 07:17:33'),
(5, 'Users', '{"users":1}', '2014-10-08 07:17:34', '2014-10-08 07:17:34'),
(6, 'Sponsors', '{"sponsors":1}', '2014-10-08 07:17:34', '2014-10-08 07:17:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_interests_categories`
--

CREATE TABLE IF NOT EXISTS `web_interests_categories` (
  `idinterests` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` text,
  `parent_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lang` varchar(4) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`idinterests`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `web_interests_categories`
--

INSERT INTO `web_interests_categories` (`idinterests`, `name`, `description`, `parent_id`, `created_at`, `updated_at`, `lang`) VALUES
(0, 'Novelas', 'Novelas', 15, '2014-09-04 00:54:02', '0000-00-00 00:00:00', 'es'),
(1, 'Outdoors', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin at magna dolor. Sed commodo feugiat lobortis. Aliquam lacinia sollicitudin porta. Nulla mollis eu enim non feugiat. Mauris convallis purus ut porta elementum. Nunc elementum ligula vel tincidunt luctus. Quisque orci enim, tempus eu fringilla a, semper ac libero. Sed condimentum leo at ipsum fringilla, ut elementum tellus ultrices. Mauris quis tempor urna, sit amet blandit lorem. In ante ante, feugiat non leo ut, molestie commodo purus. Vivamus lacinia sollicitudin urna. Aliquam et sem sed est tincidunt molestie condimentum non ligula. Quisque sed ipsum eu libero dictum pellentesque at et lorem. Morbi cursus faucibus gravida.', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(2, 'Hiking', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin at magna dolor. Sed commodo feugiat lobortis. Aliquam lacinia sollicitudin porta. Nulla mollis eu enim non feugiat. Mauris convallis purus ut porta elementum. Nunc elementum ligula vel tincidunt luctus. Quisque orci enim, tempus eu fringilla a, semper ac libero. Sed condimentum leo at ipsum fringilla, ut elementum tellus ultrices. Mauris quis tempor urna, sit amet blandit lorem. In ante ante, feugiat non leo ut, molestie commodo purus. Vivamus lacinia sollicitudin urna. Aliquam et sem sed est tincidunt molestie condimentum non ligula. Quisque sed ipsum eu libero dictum pellentesque at et lorem. Morbi cursus faucibus gravida.', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(3, 'Sailing', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin at magna dolor. Sed commodo feugiat lobortis. Aliquam lacinia sollicitudin porta. Nulla mollis eu enim non feugiat. Mauris convallis purus ut porta elementum. Nunc elementum ligula vel tincidunt luctus. Quisque orci enim, tempus eu fringilla a, semper ac libero. Sed condimentum leo at ipsum fringilla, ut elementum tellus ultrices. Mauris quis tempor urna, sit amet blandit lorem. In ante ante, feugiat non leo ut, molestie commodo purus. Vivamus lacinia sollicitudin urna. Aliquam et sem sed est tincidunt molestie condimentum non ligula. Quisque sed ipsum eu libero dictum pellentesque at et lorem. Morbi cursus faucibus gravida.', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(4, 'Cruises', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin at magna dolor. Sed commodo feugiat lobortis. Aliquam lacinia sollicitudin porta. Nulla mollis eu enim non feugiat. Mauris convallis purus ut porta elementum. Nunc elementum ligula vel tincidunt luctus. Quisque orci enim, tempus eu fringilla a, semper ac libero. Sed condimentum leo at ipsum fringilla, ut elementum tellus ultrices. Mauris quis tempor urna, sit amet blandit lorem. In ante ante, feugiat non leo ut, molestie commodo purus. Vivamus lacinia sollicitudin urna. Aliquam et sem sed est tincidunt molestie condimentum non ligula. Quisque sed ipsum eu libero dictum pellentesque at et lorem. Morbi cursus faucibus gravida.', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(5, 'Scuba Diving', 'Tutorials About Photoshop', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(6, 'Trail Running', 'Tutorials About Photoshop', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(7, 'Sport Bikes', 'Tutorials About Photoshop', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(8, 'Aviation', 'Tutorials About Photoshop', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(9, 'Adventure', 'Tutorials About Photoshop', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(10, 'Camping', 'Tutorials About Photoshop', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(11, 'Outdoor Adventures', 'Tutorials About Photoshop', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(12, 'Weekend Adventures', 'Tutorials About Photoshop', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(13, 'Live Music', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(14, 'Performing Arts', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(15, 'Collaboration', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(16, 'Artists', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(17, 'Acting', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(18, 'Theater', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(19, 'Creativity', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(20, 'Painting', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(21, 'Creative Circle', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(22, 'Arts & Entertainment', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(23, 'Graphic Design', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(24, 'Drawing', 'Tutorials About Photoshop', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(25, 'Ballroom Dancing', 'Tutorials 1', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(26, 'Dance Lessons', 'Tutorials 2', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(27, 'Belly Dance Lessons', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(28, 'Dancing', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(29, 'Social Dancing', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(30, 'Salsa', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(31, 'Latin Dance', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(32, 'Dance and Movement', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(33, 'Swing Dancing', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(34, 'Salsa Dance Lessons', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(35, 'Bachata', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(36, 'Tango', 'Tutorials', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(37, 'PTSD', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(38, 'Healthy Living', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(39, 'Intimacy', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(40, 'Meditation', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(41, 'Self-Improvement', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(42, 'Cancer Survivors', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(43, 'Medical Marijuana', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(44, 'Healthy Family', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(45, 'Special Needs Families', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(46, 'Grief Support', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(47, 'ADHD', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(48, 'Relationship Building', 'Tutorials', 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(49, 'Real Estate', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(50, 'Asian Professionals', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(51, 'Business Strategy', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(52, 'Leadership Development', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(53, 'Indian Professionals', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(54, 'Professional Development', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(55, 'Leadership', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(56, 'Golf as a Business Tool', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(57, 'Fundraising', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(58, 'Young Professionals', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(59, 'Success', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(60, 'Latino/a Professionals', 'Tutorials', 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(61, 'Dining Out', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(62, 'Pubs and Bars', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(63, 'Wine', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(64, 'Vegan', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(65, 'Beer', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(66, 'Exploring New Restaurants', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(67, 'Living Foods', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(68, 'BBQ', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(69, 'Healthy Eating', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(70, 'Indian Food', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(71, 'French Food', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(72, 'Raw Food', 'Tutorials', 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(73, 'Law of Attraction', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(74, 'Spirituality', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(75, 'Bible Study', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(76, 'Self Exploration', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(77, 'NLP', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(78, 'Catholic Social', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(79, 'Freethinker', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(80, 'Retreats', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(81, 'A Course In Miracles', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(82, 'Transformation', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(83, 'Progressive Muslim', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(84, 'Sensuality', 'Tutorials', 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(85, 'Fitness', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(86, 'Exercise', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(87, 'Walking', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(88, 'NFL Football', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(89, 'Golf', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(90, 'Pick-up Tennis', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(91, 'Volleyball', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(92, 'Water Sports', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(93, 'Cycling', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(94, 'Roller Skating', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(95, 'Recreational Sports', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(96, 'Outdoor Fitness', 'Tutorials', 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(97, 'Science', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(98, 'Education & Technology', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(99, 'Intellectual Discussion', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(100, 'Learning', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(101, 'International Relations', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(102, 'Sexual Education', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(103, 'College Alumni', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(104, 'Homeschool Support', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(105, 'Evolution', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(106, 'Communication Skills', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(107, 'Public Speaking', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(108, 'Philosophy', 'Tutorials', 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(109, 'Photography', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(110, 'Watching Movies', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(111, 'Fashion Photography', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(112, 'Film and Video Production', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(113, 'Digital Photography', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(114, 'Film', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(115, 'Photography Classes', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(116, 'Movie Nights', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(117, 'Portrait Photography', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(118, 'Group Photo Shoots', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(119, 'Model Photography', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(120, 'Nature Photography', 'Tutorials', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(121, 'African Americans', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(122, 'French Language', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(123, 'Language & Culture', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(124, 'Asians', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(125, 'Black Women', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(126, 'Multicultural', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(127, 'Indian Culture', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(128, 'Cultural Diversity', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(129, 'Black Identity', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(130, 'Latino Culture', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(131, 'Culture Exchange', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(132, 'English Language', 'Tutorials', 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(133, 'Book Club', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(134, 'Creative Writing', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(135, 'Reading', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(136, 'Poetry', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(137, 'Writing', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(138, 'Literature', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(139, 'Fiction', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(140, 'Readers', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(141, 'Writing Workshops', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(142, 'Novel Reading', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(143, 'Screenwriting', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(144, 'Novel Writing', 'Tutorials', 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(145, 'Live Music', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(146, 'Musicians', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(147, 'Singing', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(148, 'Shamanic Drumming', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(149, 'Christian Music', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(150, 'Concerts', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(151, 'Latin Music', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(152, 'Music', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(153, 'Songwriting', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(154, 'Group Singing', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(155, 'Drum Circle', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(156, 'Choir', 'Tutorials', 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(157, 'Programming', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(158, 'Blogging', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(159, 'Web Technology', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(160, 'Java', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(161, 'Artificial Intelligence', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(162, 'Software Development', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(163, 'Web Development', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(164, 'New Technology', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(165, 'Open Source', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(166, 'Web Design', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(167, 'Mobile Development', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en'),
(168, 'Technology Startups', 'Tutorials', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'en');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_migrations`
--

CREATE TABLE IF NOT EXISTS `web_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `web_migrations`
--

INSERT INTO `web_migrations` (`migration`, `batch`) VALUES
('2012_12_06_225921_migration_cartalyst_sentry_install_users', 1),
('2012_12_06_225929_migration_cartalyst_sentry_install_groups', 1),
('2012_12_06_225945_migration_cartalyst_sentry_install_users_groups_pivot', 1),
('2012_12_06_225988_migration_cartalyst_sentry_install_throttle', 1),
('2014_08_19_185847_create_comments_table', 2),
('2014_06_05_031923_create_categories_table', 3),
('2014_08_19_222718_create_rel_users_category_table', 4),
('2014_08_19_230048_create_categories_table', 5),
('2014_08_19_235412_add_name_and_location_to_the_user', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_peak_task`
--

CREATE TABLE IF NOT EXISTS `web_peak_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `type` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` int(1) NOT NULL,
  `peak_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `web_peak_task`
--

INSERT INTO `web_peak_task` (`id`, `user_id`, `title`, `description`, `type`, `created_at`, `updated_at`, `status`, `peak_id`, `event_id`) VALUES
(1, 20, 'Agradecimiento Publico grande', 'Te daremos las gracias públicamente.', 0, '2015-01-16 02:34:37', '2015-01-16 02:34:37', 0, 1, 1),
(2, 12, 'Mencion de tu marca', 'En el inicio de nuestro evento daremos un agradecimiento para tu marca al igual que un pequeño resumen de tus productos y servicios.', 0, '2015-01-26 11:26:54', '2015-01-26 11:26:54', 0, 8, 35),
(3, 16, 'Test', 'test', 0, '2015-01-26 23:53:24', '2015-01-26 23:53:24', 0, 7, 34),
(4, 12, 'Mencion de tus servicios', 'En el inicio del evento vamos a mencionar tus servicios a los asistentes.', 0, '2015-01-27 02:41:14', '2015-01-27 02:41:14', 0, 8, 35),
(5, 12, 'Envio de correo interno', 'Vamos a enviar a nuestra comunidad en un correo.', 0, '2015-01-27 10:10:09', '2015-01-27 10:10:09', 0, 8, 35),
(6, 11, 'Hacer camisetas', 'Mandar a hacer camisetas.', 1, '2015-01-27 10:44:07', '2015-01-27 10:44:07', 0, 8, 35),
(7, 11, 'Mandar a hacer calcomanias', 'Mandar a hacer calcomanias', 1, '2015-01-27 10:45:20', '2015-01-27 10:45:20', 0, 0, 35);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_rel_peaks`
--

CREATE TABLE IF NOT EXISTS `web_rel_peaks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` varchar(20) NOT NULL,
  `usd` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `id_event` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Volcado de datos para la tabla `web_rel_peaks`
--

INSERT INTO `web_rel_peaks` (`id`, `kind`, `usd`, `quantity`, `id_event`, `updated_at`, `created_at`) VALUES
(1, 'Gold', 2000, 1, 32, '2014-10-14 23:19:18', '2014-10-14 23:19:18'),
(2, 'Gold', 2000, 1, 33, '2014-10-14 23:21:03', '2014-10-14 23:21:03'),
(3, 'Plata', 1000, 10, 33, '2014-10-14 23:21:03', '2014-10-14 23:21:03'),
(4, 'Bronze', 500, 100, 33, '2014-10-14 23:21:03', '2014-10-14 23:21:03'),
(5, 'Cupper', 250, 1000, 33, '2014-10-14 23:21:03', '2014-10-14 23:21:03'),
(6, 'Plastic', 100, 10000, 33, '2014-10-14 23:21:03', '2014-10-14 23:21:03'),
(7, 'A', 23, 1, 34, '2014-10-26 07:19:22', '2014-10-26 07:19:22'),
(8, 'Gold', 50, 1, 35, '2014-10-26 07:29:53', '2014-10-26 07:29:53'),
(11, 'Gold', 5000, 1, 41, '2014-11-15 13:23:56', '2014-11-15 13:23:56'),
(12, '', 0, 1, 41, '2014-11-15 13:23:56', '2014-11-15 13:23:56'),
(13, 'Gold', 5000, 1, 42, '2014-11-15 13:31:20', '2014-11-15 13:31:20'),
(14, '', 0, 1, 42, '2014-11-15 13:31:20', '2014-11-15 13:31:20'),
(15, 'Venue', 0, 1, 43, '2014-11-17 03:11:46', '2014-11-17 03:11:46');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_rel_sponzors_events`
--

CREATE TABLE IF NOT EXISTS `web_rel_sponzors_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idsponzor` int(10) unsigned NOT NULL,
  `idevent` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` int(11) NOT NULL,
  `rel_peak` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `web_rel_sponzors_events`
--

INSERT INTO `web_rel_sponzors_events` (`id`, `idsponzor`, `idevent`, `created_at`, `updated_at`, `state`, `rel_peak`) VALUES
(1, 31, 8, '2014-12-31 03:07:46', '2014-12-31 03:07:46', 0, 8),
(2, 31, 8, '2014-12-31 03:45:22', '2014-12-31 03:45:22', 0, 8),
(3, 11, 11, '2015-01-03 10:22:38', '2015-01-03 10:22:38', 0, 11),
(4, 11, 8, '2015-01-26 22:12:50', '2015-01-27 03:12:50', 1, 8),
(5, 11, 8, '2015-01-27 05:26:21', '2015-01-27 10:26:21', 1, 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_rel_users_category`
--

CREATE TABLE IF NOT EXISTS `web_rel_users_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `rel_users_category_user_id_foreign` (`user_id`),
  KEY `rel_users_category_category_id_foreign` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=39 ;

--
-- Volcado de datos para la tabla `web_rel_users_category`
--

INSERT INTO `web_rel_users_category` (`id`, `user_id`, `category_id`, `created_at`, `updated_at`) VALUES
(10, 11, 14, '2014-10-15 05:51:27', '2014-10-15 05:51:27'),
(11, 14, 2, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(12, 15, 14, '2014-10-15 22:18:29', '2014-10-15 22:18:29'),
(13, 16, 2, '2014-10-24 22:19:54', '2014-10-24 22:19:54'),
(14, 17, 14, '2014-10-26 03:35:51', '2014-10-26 03:35:51'),
(15, 18, 14, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(16, 18, 1, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(17, 19, 14, '2014-10-28 20:17:18', '2014-10-28 20:17:18'),
(18, 20, 14, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(19, 20, 11, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(20, 20, 9, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(21, 20, 1, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(22, 21, 2, '2014-10-30 03:54:52', '2014-10-30 03:54:52'),
(23, 22, 14, '2014-11-04 11:46:36', '2014-11-04 11:46:36'),
(24, 23, 14, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(25, 24, 14, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(26, 25, 14, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(27, 27, 14, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(28, 28, 14, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(29, 29, 14, '2014-12-22 07:45:49', '2014-12-22 07:45:49'),
(30, 31, 2, '2014-12-31 03:05:27', '2014-12-31 03:05:27'),
(31, 32, 14, '2014-12-31 06:17:20', '2014-12-31 06:17:20'),
(32, 33, 14, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(33, 34, 9, '2015-01-06 08:23:27', '2015-01-06 08:23:27'),
(34, 35, 14, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(35, 39, 5, '2015-01-19 17:51:55', '2015-01-19 17:51:55'),
(36, 40, 15, '2015-01-27 01:06:21', '2015-01-27 01:06:21'),
(37, 41, 1, '2015-01-27 08:20:50', '2015-01-27 08:20:50'),
(38, 43, 14, '2015-01-27 20:52:14', '2015-01-27 20:52:14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_rel_users_interests`
--

CREATE TABLE IF NOT EXISTS `web_rel_users_interests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `interests_categories_idinterests` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `fk_rel_users_interests_web_users_idx` (`user_id`),
  KEY `fk_rel_users_interests_interests_categories1_idx` (`interests_categories_idinterests`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=152 ;

--
-- Volcado de datos para la tabla `web_rel_users_interests`
--

INSERT INTO `web_rel_users_interests` (`id`, `user_id`, `interests_categories_idinterests`, `created_at`, `updated_at`) VALUES
(11, 11, 167, '2014-10-15 05:51:27', '2014-10-15 05:51:27'),
(12, 14, 13, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(13, 14, 14, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(14, 14, 15, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(15, 14, 16, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(16, 14, 17, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(17, 14, 18, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(18, 14, 21, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(19, 14, 20, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(20, 14, 19, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(21, 14, 22, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(22, 14, 23, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(23, 14, 24, '2014-10-15 06:41:32', '2014-10-15 06:41:32'),
(24, 15, 157, '2014-10-15 22:18:29', '2014-10-15 22:18:29'),
(25, 15, 163, '2014-10-15 22:18:29', '2014-10-15 22:18:29'),
(26, 15, 165, '2014-10-15 22:18:29', '2014-10-15 22:18:29'),
(27, 15, 162, '2014-10-15 22:18:29', '2014-10-15 22:18:29'),
(28, 16, 19, '2014-10-24 22:19:55', '2014-10-24 22:19:55'),
(29, 17, 165, '2014-10-26 03:35:52', '2014-10-26 03:35:52'),
(30, 17, 166, '2014-10-26 03:35:52', '2014-10-26 03:35:52'),
(31, 17, 163, '2014-10-26 03:35:52', '2014-10-26 03:35:52'),
(32, 17, 164, '2014-10-26 03:35:52', '2014-10-26 03:35:52'),
(33, 17, 159, '2014-10-26 03:35:52', '2014-10-26 03:35:52'),
(34, 17, 157, '2014-10-26 03:35:52', '2014-10-26 03:35:52'),
(35, 17, 168, '2014-10-26 03:35:52', '2014-10-26 03:35:52'),
(36, 17, 162, '2014-10-26 03:35:52', '2014-10-26 03:35:52'),
(37, 18, 162, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(38, 18, 159, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(39, 18, 163, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(40, 18, 168, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(41, 18, 164, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(42, 18, 157, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(43, 18, 9, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(44, 18, 12, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(45, 18, 11, '2014-10-27 21:12:06', '2014-10-27 21:12:06'),
(46, 19, 157, '2014-10-28 20:17:18', '2014-10-28 20:17:18'),
(47, 19, 163, '2014-10-28 20:17:18', '2014-10-28 20:17:18'),
(48, 19, 168, '2014-10-28 20:17:18', '2014-10-28 20:17:18'),
(49, 19, 162, '2014-10-28 20:17:18', '2014-10-28 20:17:18'),
(50, 19, 159, '2014-10-28 20:17:18', '2014-10-28 20:17:18'),
(51, 20, 161, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(52, 20, 164, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(53, 20, 167, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(54, 20, 165, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(55, 20, 162, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(56, 20, 159, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(57, 20, 157, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(58, 20, 163, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(59, 20, 166, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(60, 20, 168, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(61, 20, 132, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(62, 20, 130, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(63, 20, 131, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(64, 20, 98, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(65, 20, 9, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(66, 20, 12, '2014-10-28 21:30:23', '2014-10-28 21:30:23'),
(67, 21, 14, '2014-10-30 03:54:52', '2014-10-30 03:54:52'),
(68, 21, 17, '2014-10-30 03:54:52', '2014-10-30 03:54:52'),
(69, 22, 158, '2014-11-04 11:46:36', '2014-11-04 11:46:36'),
(70, 23, 157, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(71, 23, 159, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(72, 23, 162, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(73, 23, 160, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(74, 23, 163, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(75, 23, 166, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(76, 23, 167, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(77, 23, 164, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(78, 23, 165, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(79, 23, 168, '2014-11-05 02:54:33', '2014-11-05 02:54:33'),
(80, 24, 157, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(81, 24, 160, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(82, 24, 163, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(83, 24, 166, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(84, 24, 167, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(85, 24, 164, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(86, 24, 159, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(87, 24, 162, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(88, 24, 165, '2014-11-17 02:34:09', '2014-11-17 02:34:09'),
(89, 25, 157, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(90, 25, 159, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(91, 25, 165, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(92, 25, 162, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(93, 25, 168, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(94, 25, 167, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(95, 25, 164, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(96, 25, 163, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(97, 25, 166, '2014-12-04 10:14:42', '2014-12-04 10:14:42'),
(98, 27, 164, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(99, 27, 165, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(100, 27, 168, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(101, 27, 167, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(102, 27, 166, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(103, 27, 163, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(104, 27, 157, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(105, 27, 159, '2014-12-08 22:45:54', '2014-12-08 22:45:54'),
(106, 28, 157, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(107, 28, 160, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(108, 28, 162, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(109, 28, 165, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(110, 28, 164, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(111, 28, 161, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(112, 28, 159, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(113, 28, 168, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(114, 28, 163, '2014-12-21 18:01:47', '2014-12-21 18:01:47'),
(115, 29, 168, '2014-12-22 07:45:49', '2014-12-22 07:45:49'),
(116, 31, 17, '2014-12-31 03:05:27', '2014-12-31 03:05:27'),
(117, 32, 157, '2014-12-31 06:17:20', '2014-12-31 06:17:20'),
(118, 32, 160, '2014-12-31 06:17:20', '2014-12-31 06:17:20'),
(119, 32, 165, '2014-12-31 06:17:20', '2014-12-31 06:17:20'),
(120, 33, 157, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(121, 33, 163, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(122, 33, 167, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(123, 33, 164, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(124, 33, 161, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(125, 33, 159, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(126, 33, 162, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(127, 33, 168, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(128, 33, 165, '2015-01-05 06:13:19', '2015-01-05 06:13:19'),
(129, 34, 103, '2015-01-06 08:23:27', '2015-01-06 08:23:27'),
(130, 35, 157, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(131, 35, 159, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(132, 35, 161, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(133, 35, 162, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(134, 35, 165, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(135, 35, 164, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(136, 35, 163, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(137, 35, 166, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(138, 35, 167, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(139, 35, 168, '2015-01-08 03:33:45', '2015-01-08 03:33:45'),
(140, 39, 54, '2015-01-19 17:51:55', '2015-01-19 17:51:55'),
(141, 39, 52, '2015-01-19 17:51:55', '2015-01-19 17:51:55'),
(142, 39, 51, '2015-01-19 17:51:55', '2015-01-19 17:51:55'),
(143, 39, 60, '2015-01-19 17:51:55', '2015-01-19 17:51:55'),
(144, 40, 0, '2015-01-27 01:06:21', '2015-01-27 01:06:21'),
(145, 40, 0, '2015-01-27 01:06:22', '2015-01-27 01:06:22'),
(146, 41, 2, '2015-01-27 08:20:50', '2015-01-27 08:20:50'),
(147, 43, 157, '2015-01-27 20:52:14', '2015-01-27 20:52:14'),
(148, 43, 159, '2015-01-27 20:52:14', '2015-01-27 20:52:14'),
(149, 43, 164, '2015-01-27 20:52:14', '2015-01-27 20:52:14'),
(150, 43, 163, '2015-01-27 20:52:14', '2015-01-27 20:52:14'),
(151, 43, 166, '2015-01-27 20:52:14', '2015-01-27 20:52:14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_task_by_sponzor`
--

CREATE TABLE IF NOT EXISTS `web_task_by_sponzor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `peak_id` int(11) NOT NULL,
  `sponzor_id` int(11) NOT NULL,
  `organizer_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `event_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sponzor_event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `web_task_by_sponzor`
--

INSERT INTO `web_task_by_sponzor` (`id`, `task_id`, `peak_id`, `sponzor_id`, `organizer_id`, `status`, `event_id`, `created_at`, `updated_at`, `sponzor_event_id`) VALUES
(1, 2, 8, 11, 12, 0, 35, '2015-01-27 03:12:51', '2015-01-27 03:12:51', 4),
(2, 4, 8, 11, 12, 0, 35, '2015-01-27 03:12:51', '2015-01-27 03:12:51', 4),
(3, 2, 8, 11, 12, 0, 35, '2015-01-27 10:26:21', '2015-01-27 10:26:21', 5),
(4, 4, 8, 11, 12, 0, 35, '2015-01-27 10:26:21', '2015-01-27 10:26:21', 5),
(5, 5, 8, 11, 12, 0, 35, '2015-01-27 10:26:21', '2015-01-27 10:26:21', 5),
(6, 6, 8, 11, 11, 0, 35, '2015-01-27 10:44:07', '2015-01-27 10:44:07', 4),
(7, 7, 0, 11, 11, 0, 35, '2015-01-27 10:45:20', '2015-01-27 10:45:20', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_throttle`
--

CREATE TABLE IF NOT EXISTS `web_throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `throttle_user_id_index` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=56 ;

--
-- Volcado de datos para la tabla `web_throttle`
--

INSERT INTO `web_throttle` (`id`, `user_id`, `ip_address`, `attempts`, `suspended`, `banned`, `last_attempt_at`, `suspended_at`, `banned_at`) VALUES
(24, 20, NULL, 0, 0, 0, NULL, NULL, NULL),
(25, 11, NULL, 0, 0, 0, NULL, NULL, NULL),
(26, 12, NULL, 0, 0, 0, NULL, NULL, NULL),
(27, 19, NULL, 0, 0, 0, NULL, NULL, NULL),
(28, 36, NULL, 0, 0, 0, NULL, NULL, NULL),
(29, 38, NULL, 0, 0, 0, NULL, NULL, NULL),
(30, 13, NULL, 0, 0, 0, NULL, NULL, NULL),
(31, 14, NULL, 0, 0, 0, NULL, NULL, NULL),
(32, 15, NULL, 0, 0, 0, NULL, NULL, NULL),
(33, 16, NULL, 0, 0, 0, NULL, NULL, NULL),
(34, 17, NULL, 0, 0, 0, NULL, NULL, NULL),
(35, 18, NULL, 0, 0, 0, NULL, NULL, NULL),
(36, 21, NULL, 0, 0, 0, NULL, NULL, NULL),
(37, 22, NULL, 0, 0, 0, NULL, NULL, NULL),
(38, 23, NULL, 0, 0, 0, NULL, NULL, NULL),
(39, 24, NULL, 0, 0, 0, NULL, NULL, NULL),
(40, 25, NULL, 0, 0, 0, NULL, NULL, NULL),
(41, 26, NULL, 0, 0, 0, NULL, NULL, NULL),
(42, 27, NULL, 0, 0, 0, NULL, NULL, NULL),
(43, 28, NULL, 0, 0, 0, NULL, NULL, NULL),
(44, 29, NULL, 0, 0, 0, NULL, NULL, NULL),
(45, 30, NULL, 0, 0, 0, NULL, NULL, NULL),
(46, 31, NULL, 0, 0, 0, NULL, NULL, NULL),
(47, 32, NULL, 0, 0, 0, NULL, NULL, NULL),
(48, 33, NULL, 0, 0, 0, NULL, NULL, NULL),
(49, 34, NULL, 0, 0, 0, NULL, NULL, NULL),
(50, 35, NULL, 0, 0, 0, NULL, NULL, NULL),
(51, 37, NULL, 0, 0, 0, NULL, NULL, NULL),
(52, 39, NULL, 0, 0, 0, NULL, NULL, NULL),
(53, 40, NULL, 0, 0, 0, NULL, NULL, NULL),
(54, 42, NULL, 0, 0, 0, NULL, NULL, NULL),
(55, 43, NULL, 0, 0, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_users`
--

CREATE TABLE IF NOT EXISTS `web_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `activation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `persist_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` tinyint(1) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `custom_status` int(1) NOT NULL DEFAULT '0',
  `login_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login_valid_until` timestamp NULL DEFAULT NULL,
  `lang` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `eventbriteKey` text COLLATE utf8_unicode_ci,
  `meetupRefreshKey` text COLLATE utf8_unicode_ci,
  `comunity_size` int(11) NOT NULL DEFAULT '0',
  `location` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `location_reference` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_activation_code_index` (`activation_code`),
  KEY `users_reset_password_code_index` (`reset_password_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=44 ;

--
-- Volcado de datos para la tabla `web_users`
--

INSERT INTO `web_users` (`id`, `email`, `password`, `permissions`, `activated`, `activation_code`, `activated_at`, `last_login`, `persist_code`, `reset_password_code`, `company`, `created_at`, `updated_at`, `name`, `sex`, `age`, `custom_status`, `login_code`, `login_valid_until`, `lang`, `image`, `description`, `eventbriteKey`, `meetupRefreshKey`, `comunity_size`, `location`, `location_reference`) VALUES
(11, 'ing.carlosandresrojas@gmail.com', '$2y$10$gFsa6hh0jmdsx3sV2p4xL.yGIimVJBYnqbcPr7C/e/1DB5SL3acXm', NULL, 1, NULL, '2014-10-15 05:56:57', '2015-01-27 10:21:17', '$2y$10$g0ucJR1JkY1ciw7Y92kST.LcKNuv9VxQk3ha457mtPxXU1pkQZq5S', NULL, '', '2014-10-15 05:50:54', '2015-01-27 10:21:17', NULL, 1, 18, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(12, 'juantopo@dispostable.com', '$2y$10$9MU3ukOc3vBrGhhcPwK51O4Ic17dbDO5wR2xto.Cd116HkGfkVODO', NULL, 1, NULL, '2014-10-15 06:04:44', '2015-01-28 01:22:49', '$2y$10$DUuVGBBEcWn5wl9r6wl3ze2rotYji.y/UBi21dUsGSA2gU9HQzoxm', NULL, '', '2014-10-15 06:02:08', '2015-01-28 01:28:25', NULL, NULL, NULL, 0, NULL, NULL, '', '', '', 'GGS7OEJKUZ2BWQSIXUWM', 'dc1de0e009a05a5e6df58bce007672ad', 0, '', ''),
(13, 'nike@dispostable.com', '$2y$10$3h07UqQOkmMfdpA8ZIwh.uwWo/zHJM8Ttvwk1wAyexaeTo.rohoMK', NULL, 0, '1Tj9uaFzSLIlJSAzSAnp6GT1Iy4BY40XbAbhTO46HT', NULL, NULL, NULL, NULL, '', '2014-10-15 06:22:42', '2014-10-15 06:22:42', NULL, NULL, NULL, 0, NULL, NULL, '', '', '', '', '', 0, '', ''),
(14, 'ste.daff@gmail.com', '$2y$10$HcFWziR4rfGozz7Y7zr9UOaIaaQPwRME/tP2slYkn.6eVHeqrST3e', NULL, 1, NULL, '2014-10-15 06:43:14', '2014-10-15 06:43:42', '$2y$10$5lUO5CP7EDwrLR9tgZehbuxUAAJgS3abPdgAw6jAoTW4UuCli2dwi', NULL, '', '2014-10-15 06:39:44', '2014-10-15 06:43:42', NULL, 0, 21, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(15, 'omard.skp@gmail.com', '$2y$10$opnfXqoXFD0nLbIXKUMrEuwhj90Ima1pnqddzGU40ZCcddTHj/Hrq', NULL, 1, NULL, '2014-10-15 22:18:57', '2014-10-15 22:19:08', '$2y$10$gQSU7Y/mJC.Ph7HFHcT.r.aeJmWkRKecnxjEIalDlfTlQpU/arkT.', NULL, '', '2014-10-15 22:17:20', '2014-10-15 22:19:08', NULL, 1, 25, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(16, 'seagomezar@gmail.com', '$2y$10$kFGEGmyvwEeKgv2J9Mq02ecIkVvtRtFM9huxq6kV69z4QlIByPO06', NULL, 1, NULL, '2014-10-24 22:20:46', '2015-01-28 03:55:33', '$2y$10$q7dRD172auHe1B26dWt3ceHaz4GHebOVevchsj9fAAo0j2wDWEjUq', NULL, '', '2014-10-24 22:19:18', '2015-01-28 03:55:33', 'Sebastian Alonso Gomez Arias', 1, 23, 2, NULL, NULL, '', '', '', 'OG67DVSWDWXSGXWCDLTJ', '', 0, '', ''),
(17, 'eddiezane@sendgrid.com', '$2y$10$.yOCEBXbfPYGU2O1mPMHe.Dq1U5JhotwIb6kTg1UD/1T00z0NQHMC', NULL, 1, NULL, '2014-10-26 03:36:03', '2014-10-26 03:36:10', '$2y$10$S3KpDiYypdvKv2mwxg8kLu/9.6u1yfllJQOnJFCWLefp80Zs/IytO', NULL, '', '2014-10-26 03:34:50', '2014-10-26 03:36:10', NULL, 1, 21, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(18, 'ie.cortex@gmail.com', '$2y$10$buWVSFTE4xaVpYZ3B2M5xO.9vB1M4ratkXFTVgoF5Zk6msXlps.QO', NULL, 1, NULL, '2014-10-27 21:12:35', '2014-10-27 21:13:09', '$2y$10$FzIk/jKdnpSGGcRnlVFhCelHXTgzVrN4DRkBuU641tARmObFfv9xC', NULL, '', '2014-10-27 21:09:59', '2014-10-27 21:13:09', NULL, 1, 26, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(19, 'dcifuen@gmail.com', '$2y$10$H7f9KrAt3STRr1Rk8AnIZueL.Mbs//KMMpmyPRSYmktw9mmqYjBwW', NULL, 1, NULL, '2014-10-28 20:22:12', '2015-01-16 06:43:48', '$2y$10$XJAo23KxsZv3mcxEwRIwb.bUPUdWFrHT0B0yUgvkPHMwKmQCyzjba', NULL, 'Brainz', '2014-10-28 20:15:59', '2015-01-16 06:43:48', 'David Cifuentes', 1, 29, 2, NULL, NULL, '', '', 'Somos un grupo de personas que utilizamos las tecnologías de Google a diario, ya sea en el ámbito laboral, desde el desarrollo de aplicaciones, o como usuarios finales de sus productos. Nuestro principal interés es concentrar a la comunidad de personas co', '', '0d0e01157b97e5b36f7aba483b0422a5', 0, '', ''),
(20, 'wladimiravila@gmail.com', '$2y$10$k50cZIGiulx5BIlBp02HaO/7yy8X5aWVzPOqjjT2qFJv4D4hle2o6', NULL, 1, NULL, '2014-10-28 21:31:45', '2014-10-28 22:57:27', '$2y$10$asrR2hNY1WGWg9n69Ohh1.fnXag8qcWj2SdthcNPbOxHCf2dzeOBa', NULL, '', '2014-10-28 21:28:25', '2014-10-28 22:57:27', NULL, 1, 30, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(21, 'ivanca@gmail.com', '$2y$10$SgDSG6tUVvnNtX9wiug2O.3ryLQYEjqW1xpW6dT5gisOKOictZ6Gm', NULL, 1, NULL, '2014-10-30 03:55:31', '2014-10-30 03:55:47', '$2y$10$SLOKRWKAGwNgy/t4pMOXsu5QiT6hl8BVm./YHawqtDF.rjTJE5He.', NULL, '', '2014-10-30 03:54:02', '2014-10-30 03:55:47', NULL, 0, 18, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(22, 'wjlwjl321@yahoo.com', '$2y$10$q2ZEA7dN1bAXLDVwWa51mulvg3JiPzBlyg4qRikUL7Qg9l9RPLjgW', NULL, 0, 'upBdXgoaQmb1I3StZEdHUYHQV4eT5KaHpxZYDkFsEW', NULL, NULL, NULL, NULL, '', '2014-11-04 11:46:06', '2014-11-04 11:46:36', NULL, 0, 44, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(23, 'alexcoryregistero@gmai.com', '$2y$10$u4Mfrg5QTqHSCFxjk8SGKO0coShDZy5hiUYjSnOW5wmMXe/Dnq3k2', NULL, 0, 'PcBBOYspMtNiJ3vZMmTMqHBDFVhVrMa5ZJ5eJtLtB0', NULL, NULL, NULL, NULL, '', '2014-11-05 02:53:09', '2014-11-05 02:54:33', NULL, 1, 24, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(24, 'alexcoryregister@gmail.com', '$2y$10$qkr0k0mARcrUmNhYD4ly9exKFqgOF0y4u55367tQWtJXnQBLZ3M1W', NULL, 1, NULL, '2014-11-17 02:35:42', '2014-11-17 02:50:36', '$2y$10$jcL152poxqmVWSn2lLeluONcxer1HUxobHnNWL5NALNi8Qei.NvjO', NULL, '', '2014-11-17 02:32:49', '2014-11-17 02:50:36', NULL, 1, 24, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(25, 'gatodeveloper@gmail.com', '$2y$10$HdIJ4BUHTuApX5/HxzzsFeffetBMDj2r9qWjF/SVY0bWsx1qCbWgy', NULL, 0, 'ahoy2WTxuVP3ZqmHhHIsFNJjEXSC6TwjdMx29SCbzo', NULL, NULL, NULL, NULL, '', '2014-12-04 10:11:49', '2014-12-04 10:14:42', NULL, 1, 25, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(26, 'alexp@versal.com', '$2y$10$S0dzRYzEdXF0eTMkfT8EKeElflXaBgOx.Kx0Aam5sZ7rnnL3RdAye', NULL, 0, 's0sh57PWfK7TIutxg0H0taQUQxzlqN678bJBGErNKg', NULL, NULL, NULL, NULL, '', '2014-12-06 13:03:52', '2014-12-06 13:05:50', NULL, NULL, NULL, 0, NULL, NULL, '', '', '', '', '', 0, '', ''),
(27, 'andresgz@gmail.com', '$2y$10$MB2e5NwAQl1EQ7.dIAvJpuYhN0UsH6s1KFgmAA0A51o74SN3zmoJy', NULL, 1, NULL, '2014-12-08 23:28:02', '2014-12-08 23:28:10', '$2y$10$zKlONt.VhIZQKXeC68Yog.KHANvF.YwiajhT.tg7bsc9fkSjXe0B.', NULL, '', '2014-12-08 22:44:57', '2014-12-08 23:29:20', 'Andres Gonzalez', 1, 29, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(28, 'digedez@gmail.com', '$2y$10$WsRr9DTq4BjswsyEkdDdJOadLLYImMyOkCiGJKPLeasVCK5eey2rK', NULL, 0, 'ecs1m9e4zhGA0Rv6OBy1uwjrWPkVrZvgGmYFgvGM4D', NULL, NULL, NULL, NULL, '', '2014-12-21 18:00:20', '2014-12-21 18:01:47', NULL, 1, 22, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(29, 'dylan@eventbrite.com', '$2y$10$87SYQEeYUpH.WERxQuEUGOPgcZ4jWdXJCcxDJ7/61QpZH6B3ZCLmK', NULL, 1, NULL, '2014-12-22 07:46:04', '2014-12-22 07:46:14', '$2y$10$NiXQeBOCf50eZAOwZvKx0eiOTGoJQml93lkXj4wXeQ4dVomyr0vRi', NULL, '', '2014-12-22 07:45:16', '2014-12-22 07:46:14', NULL, 1, 30, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(30, 'jeduan@gmail.com', '$2y$10$NRRk9EP9MACnhlGx75z7/uApuE1He5nE1Db37xFkmLDLbWKv/l6NS', NULL, 0, '9rUHPJvdUQgTGVccWe8VDS13tCd9PneBuKmlki4I24', NULL, NULL, NULL, NULL, '', '2014-12-24 16:23:22', '2014-12-24 16:23:22', NULL, NULL, NULL, 0, NULL, NULL, '', '', '', '', '', 0, '', ''),
(31, 'sebastian.gomez@sponzor.me', '$2y$10$jnbKq37mLMDsLUWqyaw/OefFbEFUzbkB8jDK7PFJcZyoZal2jo1IW', NULL, 1, NULL, '2014-12-31 03:07:02', '2014-12-31 03:07:22', '$2y$10$FJkUkDDD.0XhXXVWjitxtOrOJ3eSEgq2ppXaThAiARW2SMWK8zrGG', NULL, '', '2014-12-31 03:05:12', '2014-12-31 03:34:51', 'Sebastian Gomez', 1, 22, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(32, 'ecamacho.mx@gmail.com', '$2y$10$Mdf5YwC5jS9H4Y3YaZqINu/M5p7dqQbuH/i2MmM9pnNc2Bn/XtiCC', NULL, 1, NULL, '2014-12-31 06:18:01', '2014-12-31 06:18:24', '$2y$10$tnIIdDYrX0UmbD0P4Rtp0.qoj0BLKOhX9U4X1pSjJbr/3njDi6FRm', NULL, '', '2014-12-31 06:16:20', '2014-12-31 06:18:24', NULL, 1, 33, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(33, 'yo@felipejaner.com', '$2y$10$P9gPXV3KPNex8WZNjjH.t..jgi7D3sGOWeDc1DG5/kqvBwwIZCUnK', NULL, 1, NULL, '2015-01-05 06:59:10', '2015-01-05 06:59:23', '$2y$10$z5eZSdCa0eWevwIRPTHRjensnwOs6OL/hGRqJ5G0slVM9RYqhQOsO', NULL, '', '2015-01-05 06:12:32', '2015-01-05 06:59:23', NULL, 1, 25, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(34, 'frichman3@gmail.com', '$2y$10$OUtMjAIfZ5PdcgJnV6LpjeRxNOwGDQkQQ3UWkjeUhA5ThxeTE1DgS', NULL, 1, NULL, '2015-01-06 08:23:39', NULL, NULL, NULL, '', '2015-01-06 08:22:50', '2015-01-06 08:23:39', NULL, 1, 23, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(35, 'diegoct11@hotmail.com', '$2y$10$J7h/qghkRguR5grNq6PYruNR8tME0HxsfwrhNUtRgI0QlR2GQJGoS', NULL, 1, NULL, '2015-01-08 03:36:02', NULL, NULL, NULL, '', '2015-01-08 03:32:46', '2015-01-08 03:36:02', NULL, 1, 27, 2, NULL, NULL, '', '', '', '', '', 0, '', ''),
(36, 'felipeflorezg@gmail.com', '$2y$10$1.g9WPXh1LAqKbkJnwKLhesw5ZdTKteLYk4U.6KI2mr9YP68GQYSq', NULL, 1, NULL, '2015-01-16 07:55:56', '2015-01-16 07:57:03', '$2y$10$xQQ6RBbneau.FrO3YEuZHOCKpKy1e/m0UMypOOqHIcWZUfCG1H1T6', NULL, '', '2015-01-16 07:53:25', '2015-01-16 07:57:03', NULL, 1, 20, 1, NULL, NULL, '', '', '', NULL, NULL, 0, 'Colombia - Antioquia', 'CoQBgAAAAHoQwZBl8jG7JRO1CM9w9x7AnQAXHx9od8CuiGvsoZ5wsklxxEh8TqSbq8a29wEhdip45o8MR7iBznCKG0jx_43VsTTdptbMkgx4yREiP0br3sLwWmEy5c-gH-KDq-Yl996TxgDZQ171eLWr6Oem-2pKFk6CergMiGLi0lgZn9skEhBZiLqTt5LSn8il-WS1MUEfGhS8C_pFHqH17NehUjVB5_y1Z48Q9A'),
(37, 'hola@carlosrojasblog.com', '$2y$10$5R4wE/i.t1T.P0z8HwaWV.0Me6lUPrlUbru4ztaW8AEYWMoyGncEG', NULL, 0, 'd0ayhFlALYOdkoUqMmsPVLIGIktZ0c8AQfh0PwFuhj', NULL, NULL, NULL, NULL, '', '2015-01-16 21:17:41', '2015-01-16 21:17:41', NULL, NULL, NULL, 0, NULL, NULL, '', '', '', NULL, NULL, 0, '', ''),
(38, 'facebook@dispostable.com', '$2y$10$e8GTK7ssBPLGeYBj6TEPYuUHoZ.PJ0VpqlenwuxVhX64cKlUqzaeS', NULL, 1, NULL, '2015-01-18 00:56:10', '2015-01-18 00:56:39', '$2y$10$fm9MBOJZs9SUwU6DgIesx.f0wLVuMopP/viaOfm3EdGFIRqfgq8li', NULL, '', '2015-01-18 00:08:43', '2015-01-18 00:56:39', NULL, 1, 30, 1, NULL, NULL, '', '', '', NULL, NULL, 0, 'Ciudad de México, México', 'CpQBgwAAAMOsuQnj1FGKeXK7hoSxpqFU6PQRNi8fR0_zqkvbPjU56F_SHkwSWO4bgxyShRkNDzeUqNAYY9ol19Gih0DiPZ52tAcNpuY5hkZWpWuBO23sHQUcECUpl_0r2Fei_Y5bFkaLdRV8UFgyCGaFzA4di60Dve6RVfbqKp4krxN84Ngu1ZgL6uXYo9NZnhcetn65ZRIQlLn8Rkba7QSxIGsy3Shk9RoUL2mU2LFKbLxCEG0vVA4K5cl0SU0'),
(39, 'lewis@lmtm.com.ar', '$2y$10$OABQbmdypC0rCEfcyoz7j.nU3CkPSiS266q69eJImKx09i/ChDU3C', NULL, 0, 'vSPDQcNLP2Lb5spDnVY3XExNB42XBBZ0ytSP1qKz9B', NULL, NULL, NULL, NULL, '', '2015-01-19 17:50:19', '2015-01-19 17:51:55', NULL, 1, 32, 2, NULL, NULL, '', '', '', NULL, NULL, 0, 'Rosario, Santa Fe, Argentina', 'CoQBfwAAALGKE3ViJSTR5MJ4vFxpUGjjfsfAkvWA6BMpcYpQRfXYx3r1EkHQqp0VKwSLVFefxOilV5o82FCPAWYgnJhnUbMCH_U44AaLbkylOYfxwnFJwftCbiEROGv3q6tsF9IteZju9XSx5JeTtryqQsHj2GNwLM-vdg8D-uEO1zZ-cH6WEhB-RethX2Fi3LGMEdKYNl8wGhRtIUxXHpHYan-1LGPtJ15_d6zz-Q'),
(40, 'anamejias22@gmail.com', '$2y$10$uAh7rum6kKpzxSFrcEC6Zujz36hc6C73Z1H4EH00LE9TweObsiSJe', NULL, 1, NULL, '2015-01-27 03:05:55', '2015-01-28 03:29:14', '$2y$10$UVCi3p8OQlX0I.hbX8KNseCAIeyetg61s4FncBYpoQpBLaTjz2DGG', NULL, '', '2015-01-27 01:02:12', '2015-01-28 03:29:14', NULL, 0, 22, 2, NULL, NULL, '', '', '', NULL, NULL, 0, 'Valencia, Carabobo, Venezuela', 'CoQBdgAAAKkSB2xipOUa6Et2Mv-Lotkr5A3cdbTg8XfwD4RRsMiEvb1n1eP46DT1qHDsQgjaW4xeH9lwhztYWzNK5k7H7nf5u6tmJUMXHYLwjVMWZ__aEeGxM4X2yRCsbcSdu0NmlBTw9yrZsZlWP1fBEUkC3F4x_ZxMsAPmRiThsQ4He-diEhBOC5rGssURGn9NnHHdFepPGhSuds6awR0s0t--JprXJ-UNfiLxTA'),
(41, 'luisj135@hotmail.com', '$2y$10$Kh/yEMiqfDA18xUYE4MRBuR/yIE2rpGcdjnZVlOO5Uvc0sKckUYwu', NULL, 0, 'TLqDZhpTnT737eyogmlf7Cz5GDd8OZIiHyXRd7uja8', NULL, NULL, NULL, NULL, '', '2015-01-27 08:20:07', '2015-01-27 08:20:50', NULL, 0, 19, 2, NULL, NULL, '', '', '', NULL, NULL, 0, 'Bogotá, Colombia', 'CoQBfQAAAPrwFRll0VCiAZEQVxJAZu-2vI4B9DoYQR36dOAiu_d3NqsnsQLEFr96TYA5OsIVGl9UPAbvyW5-E8a8rBjHSwrMgRpNhhDo6Z0PdlukbZU6UOQN7uIHjAss8r3esHg5ZEIv4kRHvMDayOpcrCPLCwkhQFA90xPb7gBTYvaGxXcwEhAdkzX9onSgcXVxq2dECoXPGhQdlIK5iK34z7JqJ3G8Xa4KVJp0Fg'),
(42, 'luisj135@gmail.com', '$2y$10$ZbhgMTW4GW9NISaz1e6qZeTkql47Ds7D4McEgnnnHrS60qRNMZmqy', NULL, 1, NULL, '2015-01-27 08:22:56', '2015-01-27 08:28:08', '$2y$10$wALlGUvF8WJ0hmQeeeQ39ODh0RCA7f3ZhMYMyg81ftzEb..o2xbue', NULL, '', '2015-01-27 08:21:49', '2015-01-27 08:28:08', NULL, NULL, NULL, 0, NULL, NULL, '', '', '', NULL, NULL, 0, '', ''),
(43, 'hello@vitaliyg.com', '$2y$10$qhoPDwwPdRYXc4bp2RPreOnte.Q0HA3EJ6uYX3.JTraPOFi0m3KGK', NULL, 1, NULL, '2015-01-27 20:53:02', '2015-01-27 20:55:12', '$2y$10$TnZI12atCxuG8JkKYkCyH.RG8ryTz7/vzV1BHdr.tzNp46y9z76Q.', NULL, '', '2015-01-27 20:51:01', '2015-01-27 20:55:12', NULL, 1, 26, 2, NULL, NULL, '', '', '', NULL, NULL, 0, 'Miami, FL, United States', 'CoQBcQAAAP2J1O6aOu4nvs1FpHMFoMKrQgt2wbKCumLwtW8-GtJsXtO-U9NONpu43A5NtFdSkHx5TLcQGHQDvDfvw-9-_-1Cq6W3KJ-1uj_kQQOjmfBhq_nNyDKtpwax7wHbkAVscoiQwh5DyBPWqIislyuWU3DX4JovIOAOl1b62YkiTOOBEhANulIzKTcnSooJNCS64bSjGhQRm0zEY6z_EOWMuC-8X3fev3CzaQ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `web_users_groups`
--

CREATE TABLE IF NOT EXISTS `web_users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `web_users_groups`
--

INSERT INTO `web_users_groups` (`user_id`, `group_id`, `updated_at`, `created_at`) VALUES
(11, 6, '2014-10-15 05:50:55', '2014-10-15 05:50:55'),
(12, 5, '2014-10-15 06:02:09', '2014-10-15 06:02:09'),
(13, 6, '2014-10-15 06:22:43', '2014-10-15 06:22:43'),
(14, 6, '2014-10-15 06:39:44', '2014-10-15 06:39:44'),
(15, 5, '2014-10-15 22:17:21', '2014-10-15 22:17:21'),
(16, 5, '2014-10-24 22:19:19', '2014-10-24 22:19:19'),
(17, 6, '2014-10-26 03:34:51', '2014-10-26 03:34:51'),
(18, 5, '2014-10-27 21:10:01', '2014-10-27 21:10:01'),
(19, 5, '2014-10-28 20:16:00', '2014-10-28 20:16:00'),
(20, 5, '2014-10-28 21:28:26', '2014-10-28 21:28:26'),
(21, 5, '2014-10-30 03:54:06', '2014-10-30 03:54:06'),
(22, 6, '2014-11-04 11:46:07', '2014-11-04 11:46:07'),
(23, 5, '2014-11-05 02:53:10', '2014-11-05 02:53:10'),
(24, 5, '2014-11-17 02:32:49', '2014-11-17 02:32:49'),
(25, 5, '2014-12-04 10:11:50', '2014-12-04 10:11:50'),
(26, 6, '2014-12-06 13:03:53', '2014-12-06 13:03:53'),
(27, 5, '2014-12-08 22:44:57', '2014-12-08 22:44:57'),
(28, 6, '2014-12-21 18:00:22', '2014-12-21 18:00:22'),
(29, 5, '2014-12-22 07:45:16', '2014-12-22 07:45:16'),
(30, 5, '2014-12-24 16:23:23', '2014-12-24 16:23:23'),
(31, 6, '2014-12-31 03:05:12', '2014-12-31 03:05:12'),
(32, 5, '2014-12-31 06:16:21', '2014-12-31 06:16:21'),
(33, 5, '2015-01-05 06:12:32', '2015-01-05 06:12:32'),
(34, 5, '2015-01-06 08:22:50', '2015-01-06 08:22:50'),
(35, 5, '2015-01-08 03:32:47', '2015-01-08 03:32:47'),
(36, 5, '2015-01-16 07:53:25', '2015-01-16 07:53:25'),
(37, 6, '2015-01-16 21:17:43', '2015-01-16 21:17:43'),
(38, 6, '2015-01-18 00:08:44', '2015-01-18 00:08:44'),
(39, 6, '2015-01-19 17:50:20', '2015-01-19 17:50:20'),
(40, 5, '2015-01-27 01:02:14', '2015-01-27 01:02:14'),
(41, 5, '2015-01-27 08:20:07', '2015-01-27 08:20:07'),
(42, 5, '2015-01-27 08:21:49', '2015-01-27 08:21:49'),
(43, 5, '2015-01-27 20:51:02', '2015-01-27 20:51:02');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `web_rel_users_category`
--
ALTER TABLE `web_rel_users_category`
  ADD CONSTRAINT `rel_users_category_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `web_categories` (`id`),
  ADD CONSTRAINT `rel_users_category_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `web_users` (`id`);

--
-- Filtros para la tabla `web_rel_users_interests`
--
ALTER TABLE `web_rel_users_interests`
  ADD CONSTRAINT `fk_rel_users_interests_interests_categories1` FOREIGN KEY (`interests_categories_idinterests`) REFERENCES `web_interests_categories` (`idinterests`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_rel_users_interests_web_users` FOREIGN KEY (`user_id`) REFERENCES `web_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
